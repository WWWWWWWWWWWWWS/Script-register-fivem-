fx_version 'adamant'
game 'gta5'

ui_page "nui/index.html"


client_scripts {
	"config.lua",
	"client/main.lua",
}

files {
	"nui/index.html",
	"nui/vue.js",
	"nui/style.css",
	"nui/css/*.css",
	"nui/fonts/*.*",
	"nui/images/*.png",
	"nui/images/**/*.png",
}